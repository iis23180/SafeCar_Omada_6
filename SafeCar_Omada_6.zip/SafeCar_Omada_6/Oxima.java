
public class Oxima {
	private String _arithmosKikloforias;
	private String _marka;
	private String _modelo;
	private double _kibika_ekatosta;
	private String _xroma;
	
	public String getArithmos() {
		return this._arithmosKikloforias;
	}

	public void setArithmos(String aArithmos) {
		this._arithmosKikloforias=aArithmos;
	}

	public Oxima(String aArithmos, String aMarka, String aModelo, double aKibika, String aXroma) {
		_arithmosKikloforias=aArithmos;
		_marka=aMarka;
		_modelo=aModelo;
		_kibika_ekatosta=aKibika;
		 _xroma=aXroma;
	}

	public String getMarka() {
		return this._marka;
	}

	public void setMarka(String aMarka) {
		this._marka = aMarka;
	}

	public String getModelo() {
		return this._modelo;
	}

	public void setModelo(String aModelo) {
		this._modelo = aModelo;
	}

	public double getKibika() {
		return this._kibika_ekatosta;
	}

	public void setKibika(double aKibika) {
		this._kibika_ekatosta=aKibika;
	}

	public String getXroma() {
		return this._xroma;
	}

	public void setXroma(String aXroma) {
		this._xroma = aXroma;
	}
	
	public void printData()
	{
		System.out.println("Arithmos kykloforias: " +_arithmosKikloforias);
		System.out.println("Marka: " +_marka);
		System.out.println("Modelo: " +_modelo);
		System.out.println("Kibika ekatosta: "+_kibika_ekatosta);
		System.out.println("Xroma: " +_xroma);
	}

}
