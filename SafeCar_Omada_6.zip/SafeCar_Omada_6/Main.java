import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		Pelati p1=new Pelati("maria","papadopoulou","12/02/99","xarilaoy 22","kl123");
		System.out.println("Dhmiourgithike neos pelatis");
		Pelati p2=new Pelati("logan","smith","12/01/02","xarilaoy 20","xy345");
		System.out.println("Dhmiourgithike neos pelatis");
		ArrayList<Pelati> pel=new ArrayList<>();
		
		pel.add(p1);
		pel.add(p2);

		Paketo_Asfalisis pa1=new Paketo_Asfalisis("etairiaA","kathgoria1");
		Paketo_Asfalisis pa2=new Paketo_Asfalisis("etairiaB","kathgoria2");
		
		p1.addPaketo(pa1);
		p2.addPaketo(pa2);
		
		Oxima o1=new Oxima("ABC-1234","Toyota","Corolla",1600.0,"kokkino");
		Oxima o2=new Oxima("DEF-5678","Toyota","Corolla",1500.0,"kitrino");
		
		p1.addOxima(o1);
		p2.addOxima(o2);
		
		Xristis x1=new Xristis("marpap","1234");
		Xristis x2=new Xristis("logan","12345565");
		
	    p1.addXristis(x1);
	    p2.addXristis(x2);
	    
	    Symbolaio s1=new Symbolaio("maria","Toyota","paketo1","12-02","15-08",128);
	    Symbolaio s2=new Symbolaio("logan","Toyota","paketo2","05-01","18-10",180);
	    
	    p1.addSymbolaio(s1);
	    p2.addSymbolaio(s2);
	    
	    atixima a1=new atixima("12-02","tupos1","kanenas","ypaitiothta1","megethos1");
	    atixima a2=new atixima("02-12","tupos5","kwstas pap","ypaitiothta2","megethos4");
		
		p1.addatixima(a1);
		p2.addatixima(a2);
		
		for(int i=0;i<pel.size();i++)
		{
			pel.get(i).printData();
		}
		
		

	}

}
