
public class Pelati {

	private String _onoma;
	private String _eponimo;
	private String _hmerominia_gennisis;
	private String _dieuthinsi;
	private String _arithmos_Diplomatos;
	private Paketo_Asfalisis paketo;
	private Oxima oxima;
	private Xristis xristis;
	private Symbolaio symb;
	private atixima ati;
	


	public Pelati(String aOnoma, String aEponimo, String aGenhsh, String aDieuthinsi, String aArithmos) {
		_onoma=aOnoma;
		_eponimo=aEponimo;
		 _hmerominia_gennisis=aGenhsh;
		 _dieuthinsi=aDieuthinsi;
		 _arithmos_Diplomatos=aArithmos;
	}

	public String getOnoma() {
		return this._onoma;
	}

	public void setOnoma(String aOnoma) {
		this._onoma = aOnoma;
	}

	public String getEponimo() {
		return this._eponimo;
	}

	public void setEponimo(String aEponimo) {
		this._eponimo = aEponimo;
	}

	public String getHmerominia() {
		return this._hmerominia_gennisis;
	}

	public void setHmerominia(String aHmerominia) {
		this._hmerominia_gennisis=aHmerominia;
	}

	public String getDieuthinsi() {
		return this._dieuthinsi;
	}

	public void setDieuthinsi(String aDieuthinsi) {
		this._dieuthinsi = aDieuthinsi;
	}

	public String getDiploma() {
		return this._arithmos_Diplomatos;
	}

	public void setDiploma(String aArithmos) {
		this._arithmos_Diplomatos=aArithmos;
	}
	
	public void addPaketo(Paketo_Asfalisis p1)
	{
		paketo=p1;
	}
	
	public void addOxima(Oxima p1)
	{
		oxima=p1;
	}
	
	
	public void addXristis(Xristis p1)
	{
		xristis=p1;
	}
	
	public void addSymbolaio(Symbolaio p1)
	{
		symb=p1;
	}
	
	public void addatixima(atixima p1)
	{
		ati=p1;
	}
	
	public void printData()
	{
		System.out.println("Onoma: " +_onoma);
		System.out.println("Epitheto: " +_eponimo);
		System.out.println("Hmeromhnia genisis: " + _hmerominia_gennisis);
		System.out.println("Dieuthinsi: " +_dieuthinsi);
		System.out.println("Arithmos Diplomatos: " +_arithmos_Diplomatos);
		paketo.printData();
		oxima.printData();
		xristis.printData();
		symb.printData();
		ati.printData();
		
		
	}

}
