
public class Xristis {

	private String _username;
	private String _password;
	

	public Xristis(String aOnoma, String aKwdikos) {
		_username = aOnoma;
		_password = aKwdikos;
	}

	public String getUsername() {
		return this._username;
	}

	public void setUsername(String aOnoma) {
		this._username = aOnoma;
	}

	public String getPassword() {
		return this._password;
	}

	public void setPassword(String aKwdikos) {
		this._password = aKwdikos;
	}
	
	public void printData() {
		System.out.println("Username: " +_username);
		System.out.println("Kwdikos: " +_password);
	}
}
