
public class Symbolaio {
	private String _pelaths;
	private String  _oxima;
	private String _paketo_Asfalisis;
	private String _enarksi;
	private String _liksi;
	private double _kostos;
	

	

	public Symbolaio(String aPelaths, String aOxima, String aPaketo, String aEnarksi, String aLiksi, double aKostos) {
		 _pelaths=aPelaths;
		 _oxima=aOxima;
		 _paketo_Asfalisis=aPaketo;
		 _enarksi=aEnarksi;
		 _liksi=aLiksi;
		 _kostos=aKostos;
	}

	public String getPelaths() {
		return this._pelaths;
	}

	public void setPelaths(String aPelaths) {
		this._pelaths=aPelaths;}

	public String getOxima() {
		return this._oxima;
	}

	public void setOxima(String aOxima) {
		this._oxima = aOxima;
	}

	public String getPaketo() {
		return this._paketo_Asfalisis;
	}

	public void setPaketo(String aPaketo) {
		this._paketo_Asfalisis=aPaketo;
	}

	public String getEnarksi() {
		return this._enarksi;
	}

	public void setEnarksi(String aEnarksi) {
		this._enarksi = aEnarksi;
	}

	public String getLiksi() {
		return this._liksi;
	}

	public void setLiksi(String aLiksi) {
		this._liksi = aLiksi;
	}

	public double getKostos() {
		return this._kostos;
	}

	public void setKostos(double aKostos) {
		this._kostos = aKostos;
	}
	
	
	public void printData()
	{
		System.out.println("Pelaths: " +_pelaths);
		System.out.println("Oxima: " +_oxima);
		System.out.println("Paketo Asfalisis: " +_paketo_Asfalisis);
		System.out.println("Enarksi: " +_enarksi);
		System.out.println("Liksi: " + _liksi);
		System.out.println("Kostos: " +_kostos);
	}

}
