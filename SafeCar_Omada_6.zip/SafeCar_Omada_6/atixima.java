
public class atixima {

	private String _imerominia_Atiximatos;
	private String _tupos_atiximatos;
	private String _emplekomenoi_odigoi;
	private String _ypaitiotita;
	private String _megethos_Zimias;
	

	public atixima(String aImerominia, String aAtuxhma, String aOdigoi, String aYpaitiothta, String aZhmia) {
		_imerominia_Atiximatos = aImerominia;
		_tupos_atiximatos = aAtuxhma;
		_emplekomenoi_odigoi = aOdigoi;
		_ypaitiotita = aYpaitiothta;
		_megethos_Zimias = aZhmia; 
	}

	public String getImerominia() {
		return this._imerominia_Atiximatos;
	}

	public void setImerominia(String aImerominia) {
		this._imerominia_Atiximatos=aImerominia;
	}

	public String getTupos() {
		return this._tupos_atiximatos;
	}

	public void setTupos(String aAtuxhma) {
		this._tupos_atiximatos=aAtuxhma;
	}

	public String getOdigoi() {
		return this._emplekomenoi_odigoi;
	}

	public void setOdigoi(String aOdigoi) {
		this._emplekomenoi_odigoi=aOdigoi;
	}

	public String getYpaitiotita() {
		return this._ypaitiotita;
	}

	public void setYpaitiotita(String aYpaitiothta) {
		this._ypaitiotita = aYpaitiothta;
	}

	public String getZhmia() {
		return this._megethos_Zimias;
	}

	public void setZhmia(String aZhmia) {
		this._megethos_Zimias=aZhmia; 
	}
	
	public void printData() {
		System.out.println("Hmerominia atuximatos: "+ _imerominia_Atiximatos);
		System.out.println("Tupos atuximatos: " +_tupos_atiximatos);
		System.out.println("Emplekomenoi odigoi: "+_emplekomenoi_odigoi);
		System.out.println("Ypaitiothta: " +_ypaitiotita);
		System.out.println("Megethos zhmias: " +_megethos_Zimias);
	}
}
