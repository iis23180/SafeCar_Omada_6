
public class Paketo_Asfalisis {
	private String asfalistiki_etaireia;
	private String _katigoria;
	

	public Paketo_Asfalisis(String aEtairia, String aKatigoria) {
		asfalistiki_etaireia=aEtairia;
		_katigoria=aKatigoria;
	}

	public String getAsfEtairia() {
		return this.asfalistiki_etaireia;
	}

	public void setAsfEtairia(String aEtairia) {
		this.asfalistiki_etaireia=aEtairia;
	}

	public String getKatigoria() {
		return this._katigoria;
	}

	public void setKatigoria(String aKatigoria) {
		this._katigoria = aKatigoria;
	}
	
	
	public void printData() {
		System.out.println("Etairia: " + asfalistiki_etaireia);
		System.out.println("Kathgoria: " +_katigoria);
	}

}
