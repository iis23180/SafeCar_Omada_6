
public class Vehicle {

	
	private String Marka;
	private String Modelo;
	private int Year;
	private String Pinakida;
	private String Arithmos_Plaisiou;
	
	
	
	public Vehicle(String m,String o,int y,String pi,String ari)
	{
		Marka=m;
		Modelo=o;
		Year=y;
		Pinakida=pi;
		Arithmos_Plaisiou=ari;
	}
	
	
	

	public String getPinakida() {
		return Pinakida;
	}
	
	
	
}
