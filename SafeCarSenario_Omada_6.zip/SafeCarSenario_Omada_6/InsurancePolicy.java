
public class InsurancePolicy {

	private String kodikos_paketou;
	private String perigrafi;
	private int diarkeia;
	
	
	public InsurancePolicy(String ko,String peri,int dia)
	{
		kodikos_paketou=ko;
		perigrafi=peri;
		diarkeia=dia;
	}
	
	public String getPerigrafi()
	{
		return perigrafi;
	}
	
}
