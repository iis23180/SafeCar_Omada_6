
public class InsuranceContract {

	private Customer pelath;
	private Vehicle oxima;
	private InsurancePolicy ins;
	private int kostos;
	 
	
	public InsuranceContract(Customer p,Vehicle o,InsurancePolicy i, int k)
	{
		pelath=p;
		oxima=o;
		ins=i;
		kostos=k;
	}
	
	
	public void print()
	{
		System.out.println("Onoma pelath:"+pelath.getName() +"  Arithmos pinakidas:"+oxima.getPinakida() +"  Perigrafh:"
				+ ins.getPerigrafi() +"  Kostos:" +kostos);
	}
	
}
