
public class Customer {
	
	private String Name;
	private String LastName;
	private String Phone;
	private String Email;
	private String Arithmos_Taftotitas;
	
	public Customer(String name,String last,String pho,String em,String ari)
	{
		Name=name;
		LastName=last;
		Phone=pho;
		Email=em;
		Arithmos_Taftotitas=ari;
	}

	public String getName()
	{
		return Name;
	}
}
