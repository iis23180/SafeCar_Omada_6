import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		ArrayList<Customer> listCu=new ArrayList<>();
		
		Customer c1=new Customer("Maria","Papadopoulou","2310264368","maria.papadopoulou@gmail.com","AO79432");
		Customer c2=new Customer ("Evanthia","Papagianni","2310245368","evanthia.papagianni@gmail.com","AO77813");
		Customer c3=new Customer ("Vasilis","Karagiannis","2310245668","ioannis.karagiannis@gmail.com","AO45698");
		
		listCu.add(c1);
		listCu.add(c2);
		listCu.add(c3);
		
		ArrayList<Vehicle> listVe=new ArrayList<>();
		
		Vehicle v1=new Vehicle("Mercedes", "GLC", 2020, "XKP8923","7C3FR76A515072256");
		Vehicle v2=new Vehicle ("Subaru", "Forester", 2018, "NII4269","7C3FR76A555071465");
		Vehicle v3=new Vehicle ("Ford", "Ranger", 2022, "KOH4681","7C3FR76A55504645");
		
		listVe.add(v1);
		listVe.add(v2);
		listVe.add(v3);
		
		InsurancePolicy i1=new InsurancePolicy ("ΜI93", "Mikti asfalisi", 6);
		InsurancePolicy i2=new InsurancePolicy ("B56", "Basiki asfalisi", 6);
		InsurancePolicy i3=new InsurancePolicy ("O58", "Me odiki", 6);
		
  
		InsuranceContract inc1=new InsuranceContract (c1,v1,i2,60);
		InsuranceContract inc2=new InsuranceContract (c2,v2,i1,120);
		InsuranceContract inc3=new InsuranceContract (c3,v3,i3,80);
		
		
		System.out.print("Sumbolaio 1:  ");
		inc1.print();
		System.out.print("Sumbolaio 2:  ");
		inc2.print();
		System.out.print("Sumbolaio 3:  ");
		inc3.print();
		
		
		
		
		
	}
	
	
	}

	
	
